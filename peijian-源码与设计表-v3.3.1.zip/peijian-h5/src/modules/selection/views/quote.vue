﻿<!--
  页面：正式采购报价单（H5）
  路由：/quote ｜ 分组：选型与采购
  作用：与 PC 端同一口径、同一版式的正式报价单：
        居中的公司名与「报 价 单」标题、左右两栏抬头（客户 / 发件人、地址、单号）、
        八列带框明细表（序号 / 产品名称 / 规格型号 / 数量 / 单位 / 单价 / 总价 / 备注）、
        合计大写、报价说明、报价人与客户确认落款区（报价人下方为报价日期）；
        单据下方提供业务员二维码与联系电话。
        支持导出 PDF（浏览器打印）与导出图片（Canvas 绘制，同版式，不含印章）。
  数据：state.quoteItems（购物车勾选生成）或 state.selectedScheme + state.selected；
        客户名称 / 联系人 / 电话取 getters.currentCompany
-->
<template>
  <div class="m-quote">
    <!-- 操作条：返回与导出（打印/导出时隐藏） -->
    <div class="m-quote-tools">
      <button
        class="btn sm"
        type="button"
        style="margin-right: auto"
        @click="$router.back()"
      >
        返回
      </button>
      <button class="btn sm" type="button" @click="exportImage">导出图片</button>
      <button class="btn primary sm" type="button" @click="exportPdf">
        导出 PDF
      </button>
    </div>

    <!-- 报价单纸张：整体黑色细边框，与线下单据一致 -->
    <section ref="sheet" class="m-quote-sheet">
      <!-- 抬头：公司名 + 单据名 + 左右两栏信息 -->
      <div class="mq-head">
        <h1 class="mq-company">{{ seller.name }}</h1>
        <h2 class="mq-title">报 价 单</h2>

        <div class="mq-meta">
          <!-- 左栏：客户信息 -->
          <div class="mq-meta-col">
            <p><em>客户名称：</em><b>{{ customerName }}</b></p>
            <p><em>联 系 人：</em><b>{{ customerContact }}</b></p>
            <p><em>联系电话：</em><b>{{ customerPhone }}</b></p>
          </div>
          <!-- 右栏：报价方信息与单据信息 -->
          <div class="mq-meta-col">
            <p><em>发 件 人：</em><b>{{ seller.sender }}/{{ seller.phone }}</b></p>
            <p><em>公司地址：</em><b>{{ seller.address }}</b></p>
            <p><em>报价单号：</em><b>{{ quoteNo }}/{{ quoteDateCn }}</b></p>
          </div>
        </div>
      </div>

      <!-- 明细表：八列全框线 -->
      <table class="mq-table">
        <colgroup>
          <col style="width: 7%" />
          <col style="width: 25%" />
          <col style="width: 16%" />
          <col style="width: 7%" />
          <col style="width: 6%" />
          <col style="width: 13%" />
          <col style="width: 13%" />
          <col style="width: 13%" />
        </colgroup>
        <thead>
          <tr>
            <th>序号</th>
            <th>产品名称</th>
            <th>规格型号</th>
            <th>数量</th>
            <th>单位</th>
            <th>单价（RMB）</th>
            <th>总价（RMB）</th>
            <th>备注</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in tableRows" :key="row.key">
            <td>{{ row.index }}</td>
            <td class="cell-name">{{ row.name }}</td>
            <td>{{ row.model }}</td>
            <td>{{ row.qty }}</td>
            <td>{{ row.unit }}</td>
            <td>{{ row.priceText }}</td>
            <td>{{ row.totalText }}</td>
            <td>{{ row.remark }}</td>
          </tr>
        </tbody>
        <tfoot v-if="rows.length">
          <tr>
            <td colspan="6" class="cell-total-label">
              合计金额（大写）：{{ totalWords }}
            </td>
            <td class="cell-total-value">{{ money(total) }}</td>
            <td></td>
          </tr>
        </tfoot>
      </table>

      <!-- 无配置时的空态 -->
      <div v-if="!rows.length" class="mq-empty">
        没有组合，请先选配。
        <router-link class="btn sm" style="margin-top: 8px" to="/diy"
          >去一站式选配</router-link
        >
      </div>

      <!-- 报价说明 + 落款盖章 -->
      <div v-else class="mq-extra">
        <p class="mq-extra-title">报价说明：</p>
        <p v-for="(note, i) in noteLines" :key="i" class="mq-extra-line">
          {{ i + 1 }}. {{ note }}
        </p>

        <div class="mq-sign">
          <div class="mq-sign-col">
            <p>报价人：{{ seller.name }}</p>
            <p class="mq-sign-date">日期：{{ quoteDateCn }}</p>
          </div>
          <div class="mq-sign-col">
            <p>客户确认（盖章）：</p>
            <p class="mq-sign-date">日期：　　年　　月　　日</p>
          </div>
        </div>
      </div>
    </section>

    <!-- 联系业务员：二维码 + 电话，仅屏幕展示 -->
    <aside class="mq-contact">
      <QrCode :seed="7" :size="88" label="业务员微信二维码" />
      <div class="mq-contact-copy">
        <strong>{{ seller.sender }}</strong>
        <a class="mq-phone" :href="'tel:' + seller.phone">{{ seller.phone }}</a>
        <span>微信扫码或来电沟通报价细节</span>
      </div>
    </aside>
  </div>
</template>

<script>
// 领域工具：金额分转元、空字段占位
import { money, fieldValue } from "@/domain/productFields";
// 报价单口径：报价方抬头、日期、单号、金额大写
import {
  QUOTE_SELLER,
  formatCnDate,
  buildQuoteNo,
  amountInWords,
} from "@/modules/selection/domain/quoteDoc";
// 图片导出：Canvas 绘制同版式报价单
import { exportQuoteImage } from "@/modules/selection/domain/quoteImage";
// 业务员二维码：单据下方联系卡片
import QrCode from "@/components/QrCode.vue";
// 方案方向定义（direction id 转中文名）
import catalog from "@/mock/catalog.json";

// 明细表最少显示行数（不足时补空行，保持单据的表格观感）
const MIN_ROWS = 6;

export default {
  components: { QrCode },
  data() {
    const now = new Date();
    return {
      seller: QUOTE_SELLER,
      quoteNo: buildQuoteNo(now),
      quoteDateCn: formatCnDate(now),
      // 报价说明：税费、质保与效力（不含报价周期信息）
      notes: [
        "报价含 13% 增值税专用发票，运费与上门安装调试费用另计。",
        "整机质保 12 个月，易损件与耗材按实际使用情况更换。",
        "本报价为参考报价，最终以双方签订的合同为准。",
      ],
    };
  },
  computed: {
    // 购物车勾选生成报价单时的行项快照
    cartRows() {
      return this.$store.state.quoteItems || [];
    },
    scheme() {
      return this.$store.state.selectedScheme;
    },
    selected() {
      return this.$store.state.selected;
    },
    // 客户信息：取当前企业资料
    currentCompany() {
      return this.$store.getters.currentCompany;
    },
    customerName() {
      return this.currentCompany ? this.currentCompany.name : "—";
    },
    customerContact() {
      return (this.currentCompany && this.currentCompany.contact) || "—";
    },
    customerPhone() {
      return (this.currentCompany && this.currentCompany.phone) || "—";
    },
    directionName() {
      if (!this.scheme) return "";
      const d = (catalog.directions || []).find(
        (x) => x.id === this.scheme.direction
      );
      return d ? d.name : this.scheme.direction;
    },
    // 表格行归一化：购物车勾选 > 组合 parts > 自定义选配
    rows() {
      if (this.$route.query.from === "cart" && this.cartRows.length)
        return this.cartRows;
      if (this.scheme) return this.scheme.parts;
      return this.selected.map((id) => ({ id, qty: 1 }));
    },
    // 表格渲染行：真实明细 + 补齐空行（空行不参与合计）
    tableRows() {
      const list = this.rows.map((row, i) =>
        Object.assign({ key: "row-" + i, index: i + 1 }, this.formatRow(row))
      );
      for (let i = list.length; i < MIN_ROWS; i++) {
        list.push({ key: "blank-" + i, index: "", name: "", model: "" });
      }
      return list;
    },
    partCount() {
      return this.rows.reduce((n, r) => n + (r.qty || 1), 0);
    },
    total() {
      if (this.scheme && this.scheme.oneStop)
        return this.scheme.packagePriceFen;
      let sum = 0;
      for (const row of this.rows) {
        const price =
          row.unitPriceFen != null
            ? row.unitPriceFen
            : this.product(row.id).priceFen;
        if (price == null) return null;
        sum += price * (row.qty || 1);
      }
      return sum;
    },
    totalWords() {
      return amountInWords(this.total);
    },
    // 报价说明：有组合时首行补充方案信息
    noteLines() {
      if (!this.scheme) return this.notes;
      const head = `方案：${this.scheme.name}（组合型号 ${
        this.scheme.model || "待补充"
      } ｜ ${this.directionName} ｜ 共 ${this.partCount} 件）`;
      return [head].concat(this.notes);
    },
  },
  methods: {
    money,
    product(id) {
      return this.$store.getters.product(id) || {};
    },
    // 单行明细：名称 / 型号 / 数量 / 单位 / 单价 / 总价 / 备注
    formatRow(p) {
      const item = p.id ? this.product(p.id) : {};
      const qty = p.qty || 1;
      // 购物车快照自带成交价与名称时优先使用
      const price = p.unitPriceFen != null ? p.unitPriceFen : item.priceFen;
      return {
        name: p.name || item.name || "—",
        model: fieldValue(p.model !== undefined ? p.model : item.model),
        qty,
        unit: p.unit || item.unit || "台",
        priceText: money(price),
        totalText: price == null ? "待报价" : money(price * qty),
        // 备注：一站式方案里带出部品所属模块，自定义选配留空
        remark: p.module || "",
      };
    },
    // 导出图片所需数据（与页面同口径）
    exportModel() {
      return {
        seller: this.seller,
        customerName: this.customerName,
        customerContact: this.customerContact,
        customerPhone: this.customerPhone,
        quoteNo: this.quoteNo,
        quoteDateCn: this.quoteDateCn,
        rows: this.rows.map((row, i) =>
          Object.assign({ index: i + 1 }, this.formatRow(row))
        ),
        blankRows: Math.max(0, MIN_ROWS - this.rows.length),
        totalText: this.total == null ? "待报价" : money(this.total),
        totalWords: this.totalWords,
        notes: this.noteLines,
      };
    },
    // 导出 PNG
    exportImage() {
      if (!this.rows.length) {
        this.$store.commit("setNotice", "当前没有可报价的配置，请先完成选配");
        return;
      }
      exportQuoteImage(this.exportModel());
      this.$store.commit("setNotice", "报价单图片已开始下载");
    },
    // 导出 PDF：浏览器打印另存为 PDF
    exportPdf() {
      if (!this.rows.length) {
        this.$store.commit("setNotice", "当前没有可报价的配置，请先完成选配");
        return;
      }
      this.$store.commit(
        "setNotice",
        "请在打印窗口中选择「另存为 PDF」保存报价单"
      );
      window.print();
    },
  },
};
</script>

<style>
.m-quote {
  padding-bottom: 12px;
}
/* 操作条 */
.m-quote-tools {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-bottom: 10px;
}
/* ===== 报价单纸张：黑框、宋体 ===== */
.m-quote-sheet {
  border: 1px solid #111;
  background: #fff;
  color: #111;
  font-family: "SimSun", "Songti SC", "宋体", "Times New Roman", serif;
}
/* 抬头区 */
.mq-head {
  padding: 12px 10px 8px;
}
.mq-company {
  margin: 0;
  font-size: 15px;
  font-weight: 700;
  line-height: 1.35;
  letter-spacing: 1px;
  text-align: center;
}
.mq-title {
  margin: 8px 0 8px;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 7px;
  text-indent: 7px;
  text-align: center;
}
/* 抬头信息：左右两栏 */
.mq-meta {
  display: flex;
  gap: 10px;
  font-size: 8.5px;
  line-height: 1.9;
}
.mq-meta-col {
  flex: 1 1 0;
  min-width: 0;
}
.mq-meta-col p {
  display: flex;
  margin: 0;
}
.mq-meta-col em {
  flex: 0 0 auto;
  font-style: normal;
  white-space: nowrap;
}
.mq-meta-col b {
  min-width: 0;
  font-weight: 400;
  word-break: break-all;
}

/* ===== 明细表：八列全框线 ===== */
.mq-table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
  font-size: 7.5px;
}
.mq-table th,
.mq-table td {
  padding: 5px 2px;
  border: 1px solid #111;
  text-align: center;
  vertical-align: middle;
  word-break: break-all;
}
.mq-table th {
  height: 26px;
  font-weight: 700;
  line-height: 1.3;
}
.mq-table tbody tr {
  height: 26px;
}
.mq-table .cell-name {
  padding-left: 4px;
  text-align: left;
}
.mq-table .cell-total-label {
  padding-left: 4px;
  text-align: left;
}
.mq-table .cell-total-value {
  font-weight: 700;
}

/* ===== 报价说明 + 落款 ===== */
.mq-extra {
  position: relative;
  min-height: 150px;
  padding: 7px 10px 10px;
}
.mq-extra-title {
  margin: 0 0 3px;
  font-size: 9px;
}
.mq-extra-line {
  margin: 0 0 2px;
  color: #222;
  font-size: 8px;
  line-height: 1.65;
}
.mq-sign {
  position: absolute;
  right: 10px;
  bottom: 22px;
  left: 10px;
  display: flex;
  gap: 14px;
  align-items: flex-start;
  font-size: 9px;
}
.mq-sign-col {
  flex: 1 1 0;
  min-width: 0;
}
.mq-sign-col:first-child {
  flex: 0 0 46%;
}
.mq-sign p {
  margin: 0;
}
.mq-sign-date {
  margin-top: 9px !important;
  color: #333;
  font-size: 8.5px;
}

/* 空态 */
.mq-empty {
  padding: 12px 10px 16px;
  color: #333;
  font-size: 11px;
}

/* ===== 联系业务员：二维码 + 电话（打印/导出时隐藏） ===== */
.mq-contact {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 10px;
  padding: 12px;
  border: 1px solid var(--line);
  border-radius: 9px;
  background: #fff;
}
.mq-contact .qr-code {
  flex: 0 0 auto;
  border: 1px solid #eef2f7;
  border-radius: 6px;
}
.mq-contact-copy {
  display: flex;
  flex-direction: column;
  gap: 3px;
  color: var(--muted);
  font-size: 11px;
  line-height: 1.5;
}
.mq-contact-copy strong {
  color: #1f2937;
  font-size: 12px;
}
.mq-phone {
  color: var(--blue);
  font-size: 15px;
  font-weight: 700;
  letter-spacing: 0.4px;
  text-decoration: none;
}

/* 打印 / 另存为 PDF：只保留报价单纸张 */
@media print {
  @page {
    size: A4 portrait;
    margin: 10mm;
  }
  body {
    background: #fff !important;
  }
  .app > .m-header,
  .app > .tabbar,
  .app > .float-quick,
  .app > .toast,
  .m-quote-tools {
    display: none !important;
  }
  .mq-contact {
    display: none !important;
  }
  .main {
    padding: 0 !important;
    width: auto !important;
  }
  .m-quote-sheet {
    margin: 0 !important;
    border: 1px solid #111 !important;
  }
  .mq-company {
    font-size: 20px;
  }
  .mq-title {
    font-size: 17px;
  }
  .mq-meta {
    font-size: 11px;
  }
  .mq-table {
    font-size: 10.5px;
  }
  .mq-table th,
  .mq-table td {
    padding: 6px 3px;
  }
  .mq-extra {
    min-height: 160px;
  }
  .mq-extra-title {
    font-size: 11px;
  }
  .mq-extra-line {
    font-size: 10px;
  }
  .mq-sign {
    font-size: 11px;
  }
  .mq-sign-date {
    font-size: 10.5px;
  }
}
</style>
